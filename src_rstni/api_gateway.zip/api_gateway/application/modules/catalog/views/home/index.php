<div id="page-wrapper">
    <div class="row">
        <div class="col-lg-12">&nbsp;
            <!-- <h1 class="page-header">Web Service RSUD Kramat Jati</h1> -->
        </div>
        <!-- /.col-lg-12 -->
    </div>
    <div class="panel panel-default">
        <div class="panel-heading">
            <i class="fa fa-book fa-fw"></i> Katalog
        </div>
        <!-- /.panel-heading -->
        <div class="panel-body">
            <ul class="timeline">
                <li >
                    <div class="timeline-badge success"><i class="fa fa-share"></i>
                    </div>
                    <div class="timeline-panel">
                        <div class="timeline-heading">
                            <h4 class="timeline-title">Request</h4>
                            <!-- <p><small class="text-muted"><i class="fa fa-clock-o"></i> 11 hours ago via Twitter</small>
                                            </p> -->
                        </div>
                        <div class="timeline-body">
                          
                        </div>
                    </div>
                </li>
                <li class="timeline-inverted">
                    <div class="timeline-badge warning"><i class="fa fa-reply"></i>
                    </div>
                    <div class="timeline-panel">
                        <div class="timeline-heading">
                            <h4 class="timeline-title">Response</h4>
                            <!-- <p><small class="text-muted"><i class="fa fa-clock-o"></i> 11 hours ago via Twitter</small>
                                            </p> -->
                        </div>
                        <div class="timeline-body">
                            

                        </div>
                    </div>
                </li>

            </ul>
        </div>
        <!-- /.panel-body -->
    </div>


</div>
<!-- /#page-wrapper -->